<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('providers', function (Blueprint $table) {
            //step 1
            $table->id();
            $table->string('firstName');
            $table->string('lastName');
            $table->string('email')->unique();
            $table->string('token')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('phone');
            $table->string('city');
            $table->string('state');
            $table->integer('zipcode');
            //step 2s
            $table->string('practitioner_Type');
            $table->string('position_Type');
            $table->date('start_Date');
            $table->date('end_Date');
            $table->string('primary_Handedness');
            $table->string('distance_Willing_To_Travel_One_Way');
             $table->string('peferred_Daily_Working_Hours');
            //step 3
            $table->string('preferred_Daily_Patient_Volume');
            $table->string('are_You_Willing_Overnight');
            $table->string('professional_Experience');
            $table->string('booking_Availability_Requirements')->nullable();

            $table->string('dailyneeds_LatexAllergy')->nullable();
            $table->string('dailyneeds_GloveSize')->nullable();;
            $table->string('dailyneeds_SpecialNeeds')->nullable();;
            //step 4
            $table->string('available_Days');
            $table->string('procedure_Type');
            $table->string('advanced_Degree_Licences');
            $table->string('comfortable_Treating_Children');
            $table->string('qualities_Practice_Environment');
            $table->integer('average_Daily_Rate');
            $table->integer('average_hour_rate');
            //step 5
            $table->string('upload_Photo');
            $table->string('Virginia_Dental_File');
            $table->string('malpractices_Certificate');
            $table->string('dea_License');
            $table->string('description');
            $table->string('subscription');
            $table->boolean('status');
            $table->rememberToken();
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('providers');
    }
};
